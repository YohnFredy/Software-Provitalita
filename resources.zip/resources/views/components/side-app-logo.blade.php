{{-- <div>
    <img class="my-1" src="{{ asset('storage/images/logo_fornuvi_pequeño.png') }}" alt="">
</div> --}}

<div>
    <p class=" text-lg font-light text-primary/90 flex items-center">Activos <span class="text-lg font-bold text-primary ">Networks</span></p>
   
    <div class=" h-1 bg-gradient-to-r from-primary via-secondary/10 to-primary ">
  
    </div>
</div>
