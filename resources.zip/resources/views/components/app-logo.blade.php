<div>
    <p class="sm:text-lg font-light text-primary/90 flex items-center">Activos <span class="sm:text-lg font-bold text-primary ">Networks</span></p>
</div>