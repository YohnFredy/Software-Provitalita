<x-layouts.app.header>
    <flux:main>
        {{ $slot }}
    </flux:main>
</x-layouts.app.header>
