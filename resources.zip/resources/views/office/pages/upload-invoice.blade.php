<x-layouts.office title="factura">
    @livewire('invoice-upload-form2')
</x-app-layout>
