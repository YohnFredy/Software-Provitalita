
<legend {{ $attributes->class('text-base font-medium text-zinc-800 dark:text-white') }} data-flux-legend>
    {{ $slot }}
</legend>
